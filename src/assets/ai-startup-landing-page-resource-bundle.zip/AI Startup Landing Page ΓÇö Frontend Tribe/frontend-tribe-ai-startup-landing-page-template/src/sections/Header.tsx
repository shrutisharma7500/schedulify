export const Header = () => {
  return <header>Header</header>;
};

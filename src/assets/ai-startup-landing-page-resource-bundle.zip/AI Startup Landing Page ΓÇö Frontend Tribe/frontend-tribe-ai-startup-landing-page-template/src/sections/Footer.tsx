export const Footer = () => {
  return <footer>Footer</footer>;
};

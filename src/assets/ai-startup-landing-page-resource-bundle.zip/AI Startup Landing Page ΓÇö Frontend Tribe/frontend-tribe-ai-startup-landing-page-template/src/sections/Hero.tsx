export const Hero = () => {
  return <section>Hero</section>;
};

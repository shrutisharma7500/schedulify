export const LogoTicker = () => {
  return <section>LogoTicker</section>;
};

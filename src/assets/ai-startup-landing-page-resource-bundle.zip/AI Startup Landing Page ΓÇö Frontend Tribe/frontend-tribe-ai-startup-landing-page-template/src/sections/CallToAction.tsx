export const CallToAction = () => {
  return <section>CallToAction</section>;
};

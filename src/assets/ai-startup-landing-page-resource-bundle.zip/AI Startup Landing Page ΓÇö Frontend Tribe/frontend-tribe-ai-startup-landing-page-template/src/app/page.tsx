export default function Home() {
  return <div>Hello world</div>;
}
